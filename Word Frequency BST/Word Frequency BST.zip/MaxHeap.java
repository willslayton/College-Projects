/*
 *  Code referenced from Dr. Stansbury's max heap implementation:
 *  https://github.com/richss/Heap/blob/master/src/MaxHeap.java
 */

import java.util.Arrays;
import java.util.Collections;

public class MaxHeap<K extends Comparable<K>, T> {

	HeapNode<K,T> [] heap;
	int count = 0;

	public MaxHeap(int maxSize) {
		heap = new HeapNode[maxSize];
	}

	public MaxHeap(K [] priority, T [] info) {
		
		this.heap = new HeapNode[priority.length];
		this.count = priority.length;
		
		for(int i=0; i < priority.length; i++) {
			heap[i] = new HeapNode<K, T>(priority[i], info[i]);
		}
		
		floydsAlgorithm();
	}

	public void enqueue(K priority, T item) {
		
		int parent;
		int cur = count;
		heap[cur] = new HeapNode<K,T>(priority, item);
		count++;
		
		while(cur > 0) {
			parent = getParentIndex(cur);
			
			if(heap[cur].priority.compareTo(heap[parent].priority) > 0) {
				swap(cur, parent);
				cur = parent;
			} else {
				floydsAlgorithm();
				return;
			}
		}
	}

	public WordFrequency dequeue() {
		if(count == 0) {
			return null;
		}
		
		String tempWord = heap[0].info.toString();
		String tempCount = heap[0].priority.toString();
		WordFrequency temp = new WordFrequency(tempWord, tempCount);

		count--;
		heap[0] = heap[count];
		moveDown(0, count - 1);
		
		return temp;
	}

	public void moveDown(int first, int last) {
	    int cur = first;
	    int largest = 2*cur + 1;
	    
	    while(largest <= last) {
	    	if(largest < last) {
	    		if(heap[largest].priority.compareTo(heap[largest+1].priority) < 0) {
	    			largest++;
				}
			}

	    	if(heap[cur].priority.compareTo(heap[largest].priority) < 0) {
	    		swap(cur, largest);
	    		cur = largest;
	    		largest = 2*cur + 1;
	    	} else {
	    		return;
			}
	    }

	}

	private int getParentIndex(int index) {
		if ((index % 2) == 0){
			return (index - 2)/2;
		} else {
			return (index - 1)/2;
		}
	}

	private void swap(int cur, int parent) {
		HeapNode<K,T> tmp = heap[cur];
		heap[cur] = heap[parent];
		heap[parent] = tmp;
	}

	public boolean isEmpty() {
		return (count == 0);
	}

	public boolean isFull() {
		return (count == heap.length);
	}

	public class HeapNode<K, T> {

		public K priority;
		public T info;
		
		public HeapNode(K priority, T info) {
			this.priority = priority;
			this.info = info;
		}
	}

	private void floydsAlgorithm() {
		int lastNonLeaf = (heap.length/2 - 1);
		for(int i = lastNonLeaf; i >= 0; i--) {
			moveDown(i, count-1);
		}
	}

	public static Integer [] getRandomArray(int size) {

		Integer [] arr = new Integer[size];

		for (int i = 0; i < size; i++) {
			arr[i] = (size - 1) - i;
		}

		Collections.shuffle(Arrays.asList(arr));

		return arr;
	}
	
}