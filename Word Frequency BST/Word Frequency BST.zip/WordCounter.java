/**
 * Implements a word frequency counter using a binary search tree and a heap.
 * 
 * Binary Search Tree implementation works as intended, but MaxHeap does not properly implement priority queue
 */

public class WordCounter {

    public static void countWords(String [] words) {

        // Create BST object
        BinarySearchTree ascending = new BinarySearchTree();

        // Iterate through array of words
        for(int i = 0; i < words.length; i++) {
            // If there is no existing node with the word, we add it with the count of 1
            if(ascending.search(words[i]) == null) {
                ascending.insert(words[i], 1);
            
            // Otherwise we find the current count and insert that incremented by 1
            } else {
                ascending.insert(words[i], (int)ascending.search(words[i]) + 1);
            }
        }
        System.out.println("\nWords (Alphabetic Sort)\n");
        ascending.printInOrder();

        // By using the size of the BST we can initialize the MaxHeap to that maximum value
        int size = ascending.getSize();
        MaxHeap descending = new MaxHeap(size);

        // Iterate through each node in the BST
        for(int i = 0; i < size; i++) {
            // We can do this by finding the minimum node and then removing from the tree
            BinarySearchTree.BinaryTreeNode node = ascending.findMin();

            // Take the key and info from the BST
            String word = node.getInfo().toString();
            int frequency = (int)node.getKey();

            // Enqueue the key and info to the MaxHeap
            descending.enqueue(word, frequency);
            // And remove the node from the BST
            ascending.delete(word);
        }

        System.out.println("\n\nWords (Frequency Sort)\n");
        // To print each value in the queue we dequeue all words until the queue is empty
        while(!descending.isEmpty()) {
            WordFrequency wordComparable = descending.dequeue();
            System.out.println(wordComparable.getWord() + " => " + wordComparable.getCount());
        }
        
    }

    public static void main(String [] args) {
        String input = "input.txt";
        WordCounter.countWords(InputReader.parseInputFile(input));
    }
}
