/*
 *  Code referenced from Dr. Stansbury's binary search tree implementation:
 *  https://github.com/richss/CS315-2019-bst/blob/master/src/BinaryTreeNode.java
 */

public class BinaryTreeNode<K, T> {

    protected K key;
    protected T info;
    protected BinaryTreeNode<K,T> left;
    protected BinaryTreeNode<K,T> right;

    public BinaryTreeNode(K key, T info) {
        this.key = key;
        this.info = info;
        left = right = null;
    }

    public K getKey() {
        return key;
    }

    public T getInfo() {
        return info;
    }

    public BinaryTreeNode<K, T> getLeft() {
        return left;
    }

    public BinaryTreeNode<K,T> getRight() {
        return right;
    }

}