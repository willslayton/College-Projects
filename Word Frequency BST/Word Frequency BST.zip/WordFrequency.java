// WordFrequency class provides comparable object for word with count
public class WordFrequency implements Comparable<WordFrequency> {

    private String word;
    private String count;
    
    public WordFrequency(String w, String c) {
        this.word = w;
        this.count = c;    
    }

    public int compareTo(WordFrequency other) {
        return (Integer.parseInt(count) - Integer.parseInt(other.count));
    }

    public String getCount() {
        return count;
    }

    public String getWord() {
        return word;
    }
}