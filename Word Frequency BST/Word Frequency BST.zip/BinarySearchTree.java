/*
 *  Code referenced from Dr. Stansbury's binary search tree implementation:
 *  https://github.com/richss/CS315-2019-bst/blob/master/src/BinarySearchTree.java
 */

import java.util.ArrayDeque;
import java.util.Deque;

public class BinarySearchTree<K extends Comparable<? super K>, T> {

    // Declare our root node and size
    private BinaryTreeNode<K,T> root;
    private int size;

    // Constructor initializes values
    public BinarySearchTree() {
        size = 0;
        root = null;
    }

    public void insert(K key, T info) {
        root = insert(root, key, info);
    }

    // Insert method
    private BinaryTreeNode<K, T> insert(BinaryTreeNode<K,T> node, K key, T info) {
        // If there is no node, create a node
        if(node == null) {
            node = new BinaryTreeNode<>(key, info);
            size++;
        // Otherwise find the proper location for the node recursively
        } else {
            int compare = key.compareTo(node.key);

            if(compare == 0) {
                node.info = info;
            } else if(compare < 0) {
                node.left = insert(node.left, key, info);
            } else if(compare > 0) {
                node.right = insert(node.right, key, info);
            }
        }
        return node;
    }

    public void printInOrder() {
        inOrderTraverse(root);
    }

    // Follows in-order traversal through the BST and prints each key and info
    private void inOrderTraverse(BinaryTreeNode<K,T> cur) {
        if(cur == null) {
            return;
        }

        inOrderTraverse(cur.left);
        System.out.println(cur.key + " => " + cur.info);
        inOrderTraverse(cur.right);
    }

    public T search(K key) {
        return search(root, key);
    }

    // Search method uses comparable to return node info
    private T search(BinaryTreeNode<K,T> cur, K key) {
        if(cur == null) {
            return null;
        }

        if(key.equals(cur.key)) {
            return cur.info;
        }

        if(key.compareTo(cur.key) < 0) {
            return search(cur.left, key);
        }

        return search(cur.right, key);
    }

    public void delete(K key) {
        size--;
        root = deleteByCopy(root, key);
    }

    // Delete removes nodes by copying a node upwards
    private BinaryTreeNode<K,T> deleteByCopy(BinaryTreeNode<K,T> cur, K key) {
        if(cur == null) {
            return null;
        }

        // If the node is not found, recurse
        if(key.compareTo(cur.key) < 0) {
            cur.left = deleteByCopy(cur.left, key);
            return cur;
        } else if(key.compareTo(cur.key) > 0) {
            cur.right = deleteByCopy(cur.right, key);
        } else {
            // If there is only one child, then bring that child up
            if(cur.left == null) {
                return cur.right;
            } else if(cur.right == null) {
                return cur.left;

            // Otherwise find the minimum value of the right subtree to replace the node
            } else {
                BinaryTreeNode<K, T> successor = findMin(cur.right);
                cur.key = successor.key;
                cur.info = successor.info;
                cur.right = deleteByCopy(cur.right, cur.key);
                return cur;
            }
        }
        
        return null;
    }

    // Helper functions

    public BinaryTreeNode<K, T> findMin() {
        if(root == null) {
            return null;
        }

        return findMin(root);
    }

    public int getSize() {
        return size;
    }

    private BinaryTreeNode<K, T> findMin(BinaryTreeNode<K,T> cur) {
        if(cur.left == null) {
            return cur;
        }

        return findMin(cur.left);
    }

    public BinaryTreeNode<K, T> findMax() {
        if(root == null) {
            return null;
        }

        return findMax(root);
    }

    private BinaryTreeNode<K, T> findMax(BinaryTreeNode<K,T> cur) {
        if(cur.right == null) {
            return cur;
        }

        return findMax(cur.right);
    }

    // Class for BinaryTreeNode

    public class BinaryTreeNode<K, T> {

        // Each node keeps track of the user-defined key and info as well as its left and right child
        protected K key;
        protected T info;
        protected BinaryTreeNode<K,T> left;
        protected BinaryTreeNode<K,T> right;

        public BinaryTreeNode(K key, T info) {
            this.key = key;
            this.info = info;
            left = right = null;
        }

        public K getKey() {
            return key;
        }

        public T getInfo() {
            return info;
        }

        public BinaryTreeNode<K, T> getLeft() {
            return left;
        }

        public BinaryTreeNode<K,T> getRight() {
            return right;
        }
    }
}