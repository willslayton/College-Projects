/* -----------------------------------------------
    Submitted By: Will Slayton
    Homework Number: Final project
    Credit to:
        N/A

    Submitted On: April 23, 2019
    By submitting this program with my name,  I affirm that the creation and modification of this program is primarily my own work.
------------------------------------------------ */

/* This program should use the console to play a racing game with an automatic or manual mode. In the automatic mode the racers and cars are taken directly from the car.txt file 
 and automatically raced to determine a winner, whereas in the manual mode two players are asked to pick their cars and then the race uses user input to know when to make the 
 next move. */

// Including useful libraries
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

// Defining the structure for the data of cars
struct car{
    char driver[25];
    char make[25];
    int number;
    char color[13];
    int position;
};

// Prototypes for functions
int randomNum (int limit);
int getNumOfRacers (void);
void Racer (int number, int position);
void manualRace (struct car *carDataPtr, int numOfRacers);
void autoRace (struct car *carDataPtr, int numOfRacers);
void modifyCar (struct car *carDataPtr, int numOfRacers);
void chooseCar (struct car *carDataPtr, struct car *userDataPtr, int numOfRacers);
void doRace (struct car *carDataPtr, int numOfRacers, int is_auto_race);

int main (void){
    // Creating a file pointer to read car data from the car.txt file
    FILE *fpCarData = fopen("car.txt", "r");
    // Defining variables
    int i = 0, user_game_choice = 0, numOfRacers = getNumOfRacers();
    struct car carData[numOfRacers];
    // Creating pointer to an array of the car structure
    struct car *carDataPtr = carData;
    // Clearing the console
    system("CLS");
    // Scanning the data from the text file to the array until it reaches the end of the file
    while (fscanf(fpCarData, "%s %s %d %s", &carData[i].driver, &carData[i].make, &carData[i].number, &carData[i].color)==4){
        i++;
    }
    // Closing the file pointer
    fclose (fpCarData);
    // Checking if the user chose the quit case
    while (user_game_choice != 3){
        system("CLS");
        // Printing options for user to select
        printf("Main Menu > Would you like to: \n\t1. Race against another user \n\t2. Run the race with four cars automatically\n\t3. Quit\n");
        // Scanning what case the user decides to choose
        scanf("%d", &user_game_choice);
        // Switch based on what the user decided on
        switch (user_game_choice){
            case 1:
                // If 1, call the manual race function
                manualRace(carDataPtr, numOfRacers);
                break;
            case 2:
                // If 2, call the automatic race function
                autoRace(carDataPtr, numOfRacers);
                break;
            case 3:
                // If 3, break to reach the end of function
                break;
        }
    }
    return 0;
}

int randomNum (int limit){
    // Defining variables
    int number;
    // Taking random seed from the system time
    srand (time(NULL));
    // Set a number equal to one plus the modulus of a random number and the defined limit
    number = (rand() % limit) + 1;
    // Return the number
    return number;
}

int getNumOfRacers (void){
    // Creating a file pointer to read car data from the car.txt file
    FILE *fpCarData = fopen("car.txt", "r");
    // Defining variables
    char empty [100];
    int i = 0;
    // Using fgets to iterate through and check how many lines in the file there are
    while (fgets(empty, 99, fpCarData)){
        i++;
    }
    // Closing the file pointer
    fclose(fpCarData);
    // Return the number of lines
    return i;
}

void Racer (int number, int position){
    // Defining variables
    int i;
    // Print the number of the car before anything else
    printf("#%d\t", number);
    // If the position of the car is over 90, then set it to 90 since that is the maximum
    if(i > 90){
        i = 90;
    }
    // For the current position print that many asterisks
    for (int i = 0; i < position; i++){
        printf("*");
    }
}

void manualRace (struct car *carDataPtr, int numOfRacers){
    // Defining variables
    int user_race_choice = 0;
    struct car userData [2];
    struct car *userDataPtr = userData;
    // Checking if the user chose the quit case
    while (user_race_choice != 3){
        system("CLS");
        // Printing options for user to select
        printf("Manual Race > Would you like to: \n\t1. Start the race \n\t2. Modify the cars\n\t3. Exit to main menu\n");
        // Scanning what case the user decides to choose
        scanf("%d", &user_race_choice);
        // Switch based on what the user decided on
        switch (user_race_choice){
            case 1:
                // If 1, make the user choose a car and then start the manual game
                chooseCar(carDataPtr, userDataPtr, numOfRacers);
                doRace(userDataPtr, 2, 0);
                break;
            case 2:
                // If 2, call the car modification function
                modifyCar(carDataPtr, numOfRacers);
                break;
            case 3:
                break;
                // If 3, break to reach the end of function
        }
    }
}

void autoRace (struct car *carDataPtr, int numOfRacers){
    // Defining variables
    int user_race_choice = 0;
    // Checking if the user chose the quit case
    while (user_race_choice != 3){
        system("CLS");
        // Printing options for user to select
        printf("Automatic Race > Would you like to: \n\t1. Start the race \n\t2. Modify the cars\n\t3. Exit to main menu\n");
        // Scanning what case the user decides to choose
        scanf("%d", &user_race_choice);
        // Switch based on what the user decided on
        switch (user_race_choice){
            case 1:
                // If 1, start an automatic game
                doRace(carDataPtr, numOfRacers, 1);
                break;
            case 2:
                // If 2, call the car modification function
                modifyCar(carDataPtr, numOfRacers);
                break;
            case 3:
                break;
                // If 3, break to reach the end of function
        }
    }
}

void modifyCar (struct car *carDataPtr, int numOfRacers){
    // Defining variables
    int i = 0, car_to_modify, data_to_modify;
    system("CLS");
    printf("Choose a car from the list to modify and enter the corresponding number:\n");
    // List all of the cars and their details for the user to select from
    for (i = 0; i < numOfRacers; i++){
        printf("\t(%d) %s %s %d %s\n", i+1, (carDataPtr + i)->driver, (carDataPtr + i)->make, (carDataPtr + i)->number, (carDataPtr + i)->color);
    }
    // Scanning what case the user decides to choose
    scanf("%d", &car_to_modify);
    system("CLS");
    printf("Choose a part from the list to modify and enter the corresponding number:\n");
    // Printing options for user to select
    printf("\t(1) Driver\n\t(2) Make\n\t(3) Number\n\t(4) Color\n");
    scanf("%d", &data_to_modify);
    // Scanning what the user decides to choose
    system("CLS");
    // Switch for which member of data the user would like to modify
    switch (data_to_modify){
        case 1:
            printf("Enter the new driver: ");
            scanf("%s", (carDataPtr + (car_to_modify-1))->driver);
            break;
        case 2:
            printf("Enter the new make: ");
            scanf("%s", (carDataPtr + (car_to_modify-1))->make);
            break;
        case 3:
            printf("Enter the new number: ");
            scanf("%d", (carDataPtr + (car_to_modify-1))->number);
            break;
        case 4:
            printf("Enter the new make: ");
            scanf("%s", (carDataPtr + (car_to_modify-1))->color);
            break;
    }
    // Creating a file pointer to read car data from the car.txt file
    FILE *fpCarData = fopen("car.txt", "w");
    // Writing the new data for all cars to the text file
    for (i = 0; i < numOfRacers; i++){
        fprintf(fpCarData, "%s %s %d %s\n", (carDataPtr + i)->driver, (carDataPtr + i)->make, (carDataPtr + i)->number, (carDataPtr + i)->color);
    }
    // Closing the file pointer
    fclose (fpCarData);
}

void chooseCar (struct car *carDataPtr, struct car *userDataPtr, int numOfRacers){
    // Defining variables
    int j = 0, i = 0, userChoice[2] = {0};
    // For each player in the manual game let them choose their car
    for (j = 0; j < 2; j++){
        system("CLS");
        printf("Player %d, choose a car from the list and enter the corresponding number:\n", j+1);
        // Print out list of cars for user to choose from
        for (i = 0; i < numOfRacers; i++){
            // Remove the car that Player 1 already picked from the list
            if(i != (userChoice[0]-1)){
                printf("\t(%d) %s %s %d %s\n", i+1, (carDataPtr + i)->driver, (carDataPtr + i)->make, (carDataPtr + i)->number, (carDataPtr + i)->color);
            }
        }
        // Scanning what the user decides to choose
        scanf("%d", &userChoice[j]);
        // Copying the data of the chosen cars from the original array of structures to one just for containing the user cars
        strcpy((userDataPtr+j)->driver, ((carDataPtr+(userChoice[j]-1))->driver));
        strcpy((userDataPtr+j)->make, ((carDataPtr+(userChoice[j]-1))->make));
        (userDataPtr+j)->number = (carDataPtr+(userChoice[j]-1))->number;
        strcpy((userDataPtr+j)->color, ((carDataPtr+(userChoice[j]-1))->color));
    }
}

void doRace (struct car *carDataPtr, int numOfRacers, int is_auto_race){
    // Defining variables
    int j = 0, i = 0, raceHasNotEnded = 1, carToMove, extraPositionSortValue, extraIdSortValue, carDistance, sortPositionArray[numOfRacers], sortIdArray[numOfRacers];
    system("CLS");
    // For the number of cars in the array of structure set all of the positions to zero and the corresponding values in the sorting arrays to the element number and zero
    for (i = 0; i < numOfRacers; i++){
        (carDataPtr + i)->position = 0;
        sortIdArray[i] = i;
        sortPositionArray[i] = 0;
    }
    // Check if the race has ended
    while(raceHasNotEnded){
        // Check if race is automatic or not
        if(is_auto_race != 1){
            // If the race isn't automatic, then prompt the user to press the spacebar for movement
            printf("\nPress the spacebar to move the cars\n");
            // Get the key pressed and do nothing while it's not equal to the space character
            while(getch() != ' '){}
        }
        system("CLS");
        // Randomly pick the distance from the start of the array of which car to move
        carToMove = randomNum(numOfRacers) - 1;
        // Randomly pick the distance that the randomly selected car should move
        carDistance = randomNum(10);
        // Set the car's position to the sum of the old position and the new distance
        (carDataPtr + carToMove)->position += carDistance;
        // Set the original value of the position sorting array to the current car's position
        sortPositionArray[carToMove] = (carDataPtr + carToMove)->position;
        // Iterate through each of the cars
        for (i = 0; i < numOfRacers; i++){
            // Create the racetrack for the current car
            Racer((carDataPtr + i)->number, (carDataPtr + i)->position);
            printf("\n");
            // If the position goes beyond the finish line then set it back to the finish line
            if((carDataPtr + i)->position >= 90){
                (carDataPtr + i)->position = 90;
                // Make the race end
                raceHasNotEnded = 0;
            }
        }
    }
    // Iterate through the less than check for each of the cars to ensure the arrays are fully sorted
    for(j = 0; j < numOfRacers; j++){
        for (i = 0; i < (numOfRacers-1); i++){
            // Check if the ith position is less than the i+1st position
            if(sortPositionArray[i] < sortPositionArray[i+1]){
                // Using a dummy variable swap the values at i and i+1 in the position array
                extraPositionSortValue = sortPositionArray[i];
                sortPositionArray[i] = sortPositionArray[i+1];
                sortPositionArray[i+1] = extraPositionSortValue;
                // Using a dummy variable swap the values at i and i+1 in the id array
                extraIdSortValue = sortIdArray[i];
                sortIdArray[i] = sortIdArray[i+1];
                sortIdArray[i+1] = extraIdSortValue;
            }
        }
    }
    // Print header for the ranking
    printf("\n\nRank\tDriver\t\tMake\t\tNumber\tColor\tDistance\n");
    // Creating a file pointer to read car data from the car.txt file
    FILE *fpResults = fopen("raceresult.txt", "w");
    // Iterate through each of the cars in the race
    for (i = 0; i < numOfRacers; i++){
        // Check the length of the driver and make strings to see how many \t characters are needed to align the values in the table for the print
        if(strlen((carDataPtr + sortIdArray[i])->make)>8){
            printf("#%d\t%s\t\t%s\t%d\t%s\t%d\n", i+1, (carDataPtr + sortIdArray[i])->driver, (carDataPtr + sortIdArray[i])->make, (carDataPtr + sortIdArray[i])->number, (carDataPtr + sortIdArray[i])->color, (carDataPtr + sortIdArray[i])->position);
        } else if(strlen((carDataPtr + sortIdArray[i])->driver)>8){
            printf("#%d\t%s\t%s\t\t%d\t%s\t%d\n", i+1, (carDataPtr + sortIdArray[i])->driver, (carDataPtr + sortIdArray[i])->make, (carDataPtr + sortIdArray[i])->number, (carDataPtr + sortIdArray[i])->color, (carDataPtr + sortIdArray[i])->position);
        } else if((strlen((carDataPtr + sortIdArray[i])->make)>8)&&(strlen((carDataPtr + sortIdArray[i])->driver)>8)){
            printf("#%d\t%s\t%s\t%d\t%s\t%d\n", i+1, (carDataPtr + sortIdArray[i])->driver, (carDataPtr + sortIdArray[i])->make, (carDataPtr + sortIdArray[i])->number, (carDataPtr + sortIdArray[i])->color, (carDataPtr + sortIdArray[i])->position);
        } else {
            printf("#%d\t%s\t\t%s\t\t%d\t%s\t%d\n", i+1, (carDataPtr + sortIdArray[i])->driver, (carDataPtr + sortIdArray[i])->make, (carDataPtr + sortIdArray[i])->number, (carDataPtr + sortIdArray[i])->color, (carDataPtr + sortIdArray[i])->position);
        }
        // File print the name of the driver and the rank to the text file
        fprintf(fpResults, "%s #%d\n", (carDataPtr + sortIdArray[i])->driver, i+1);
    }
    // Closing the file pointer
    fclose(fpResults);
    printf("\nPress ENTER to continue.\n");
    // Get the key pressed and do nothing while it's not equal to the return or newline characters
    while(!((getch() == '\r')||(getch() == '\n'))){}
}
