import sys
from random import randint

def makeFile(size):
    # Create blank file to use as seek requests
    file = open("seek.txt", "w")
    file.write("")
    file.close()

    file = open("seek.txt", "a")
    i = 0
    while (i < size):
        # Newline will be used to separate numbers
        file.write(str(randint(0, 99)) + "\n")
        i += 1
    file.close()
    return("seek.txt")

def readFile(filename):
    file = open(filename, "r")
    # Split the disk file at each newline into an array
    seeks = file.read().splitlines()
    # Convert all elements of seeks list to integers
    # Duplicate array for each algorithm to use
    fifo_seeks = [int(i) for i in seeks]
    sstf_seeks = [int(i) for i in seeks]
    scan_seeks = [int(i) for i in seeks]
    c_scan_seeks = [int(i) for i in seeks]

    # Find the distance for two different disk scheduling algorithms
    fifo_dist = FIFO(fifo_seeks)
    sstf_dist = SSTF(sstf_seeks)
    scan_dist = SCAN(scan_seeks)
    c_scan_dist = C_SCAN(c_scan_seeks)

    print("\n")
    print("FIFO distance traversed: " + str(fifo_dist) + "\n")
    print("SSTF distance traversed: " + str(sstf_dist) + "\n")
    print("Scan distance traversed: " + str(scan_dist) + "\n")
    print("C-Scan distance traversed: " + str(c_scan_dist) + "\n")
    print("\n")


# Since seeks is a list of strings we must cast to int whenever using an element

def FIFO(seeks):
    # Initialize distance to zero and the head to the first seek
    distance = 0
    head = seeks[0]

    for seek in seeks:
        # Add the difference of head and next seek to distance
        distance += abs(head - seek)
        head = seek
    return distance

def SSTF(seeks):
    distance = 0
    head = seeks[0]
    
    # Sort our seeks to easily see which are closer in range to others
    seeks.sort()
    i = seeks.index(head)
    while(len(seeks) > 1):
        # Check for i being 0 or the last element
        # Whichever extreme we are at we can set the lowDist/highDist to 100 which is beyond the maximum integer value
        # Thus the direction will not be selected for the algorithm
        if(i == 0):
            highDist = abs(seeks[i + 1] - head)
            lowDist = 100
        elif(i == len(seeks) - 1):
            lowDist = abs(seeks[i - 1] - head)
            highDist = 100
        # Otherwise we find the distance of moving to either a higher or lower track
        else:
            highDist = abs(seeks[i + 1] - head)
            lowDist = abs(seeks[i - 1] - head)
        
        # Check which direction has the shortest distance
        if(highDist >= lowDist):
            head = seeks[i - 1]
            distance += lowDist
            seeks.pop(i)
            i -= 1
        else:
            head = seeks[i + 1]
            distance += highDist
            seeks.pop(i)
            # We don't need to increment i because popping the element does this
    return distance

def SCAN(seeks):
    distance = 0
    head = seeks[0]

    i = 0
    moveHigher = True

    while(len(seeks) > 1):
        # Check if the value of i is reaching either end of the list
        if((not moveHigher) and (i == 0)):
            moveHigher = True
            distance += abs(head - seeks[i])
            head = seeks[i]
            seeks.pop(i)
        elif(moveHigher and (i == len(seeks) - 1)):
            moveHigher = False
            distance += abs(head - seeks[i])
            head = seeks[i]
            seeks.pop(i)
            i -= 1
        elif(moveHigher and (seeks[i] > head)):
            distance += abs(head - seeks[i])
            head = seeks[i]
            seeks.pop(i)
            # We don't need to increment i because popping the element does this
        elif((not moveHigher) and (seeks[i] < head)):
            distance += abs(head - seeks[i])
            head = seeks[i]
            seeks.pop(i)
            i -= 1
        else:
            # Increment or decrement based on moveHigher
            if(moveHigher):
                i += 1
            else:
                i -= 1
    return distance

def C_SCAN(seeks):
    distance = 0
    head = seeks[0]

    i = 0
    while(i < len(seeks)):
        # If the seek at index i is larger than the position of head then we move there in our sweep
        if(seeks[i] > head):
            distance += abs(head - seeks[i])
            head = seeks[i]
            seeks.pop(i)
        elif(i == len(seeks) - 1):
            # i is set to 0 as our sweep back to the start
            i = 0
            distance += abs(head - seeks[i])
            head = seeks[i]
            seeks.pop(i)
        else:
            i += 1
    return distance

# Pass into the main call the number of elements the file should have
def main(size):
    readFile(makeFile(size))

main(1000)
