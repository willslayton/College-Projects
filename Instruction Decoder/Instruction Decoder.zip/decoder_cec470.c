/*
CEC 470 Instruction Decoder Project
Team 8: Hailey DeNys, Jacob Stephans, Will Slayton
Due: 11/11/2021
*/

#define HALT_OPCODE 0x19

void fetchNextInstruction(void);
void executeInstruction(void);

unsigned char memory[65536]; // memory array
unsigned char ACC=0;    // accumulator 8 bit
unsigned char IR=0;     // Instruction register 8 bit
unsigned int MAR=0;     // Memory address register 16 bit - indirect reference to data in memory
unsigned int PC=0;      //Program counter 16 bit - holds address of next instruction to execute

int main(int argc, CHAR* argv[])
{

// Execution loop. Continue fetching and executing until
// PC points to a halt instruction
    while(memory[PC] != HALT_OPCODE){
        fetchNextInstruction();
        executeInstruction();
    }
    return 0;
}

void fetchNextInstruction()
{

	// retrieve instruction from memory[PC] and store in IR
	IR = memory[PC];

	// determine from the instruction how much to increment PC
	// so it points to the next instruction in memory + perform increment

	// checking opcode
	if((IR & 0x80) == 0x80) /* Mathematical Operation */
	{
	    // check destination
        switch(IR & 0x0c){

            case 0x00:
                // indirect (MAR used as pointer);
                switch(IR & 0x03){

                    case 0x00:
                        // indirect (MAR used as pointer)
                        break;
                    case 0x01:
                        // Accumulator ACC
                        break;
                    case 0x02:
                        // Constant is passed to processor as 8
                        // or 16 bit operand following the opcode
                        PC++;
                        break;
                    case 0x03:
                        // memory address is passed to the processor as a
                        // 16-bit operand following the opcode
                        PC+=2;
                        break;
                    default:
                        break;
                }
            case 0x04:
                // accumulator ACC
                switch(IR & 0x03){

                    case 0x00:
                        // indirect (MAR used as pointer)
                        break;

                    case 0x01:
                        // Accumulator ACC
                        break;

                    case 0x02:
                        // Constant is passed to processor as 8
                        // or 16 bit operand following the opcode
                        PC++;
                        break;

                    case 0x03:
                        // memory address is passed to the processor as a
                        // 16-bit operand following the opcode
                        PC+=2;
                        break;

                    default:
                        break;
                }
            case 0x08:
                // address register MAR
                switch(IR & 0x03){

                    case 0x00:
                        // indirect (MAR used as pointer)
                        break;

                    case 0x01:
                        // Accumulator ACC
                        break;

                    case 0x02:
                        // Constant is passed to processor as 8
                        // or 16 bit operand following the opcode
                        PC+=2;
                        break;

                    case 0x03:
                        // memory address is passed to the processor as a
                        // 16-bit operand following the opcode
                        PC+=2;
                        break;

                    default:
                        break;
                }
            case 0x0c:
                // memory address is passed to the processor as a
                // 16-bit operand following the opcode
                switch(IR & 0x03){

                    case 0x00:
                        // indirect (MAR used as pointer)
                        PC+=2;
                        break;

                    case 0x01:
                        // Accumulator ACC
                        PC+=2
                        break;

                    case 0x02:
                        // Constant is passed to processor as 8
                        // or 16 bit operand following the opcode
                        PC+=3;
                        break;

                    case 0x03:
                        // memory address is passed to the processor as a
                        // 16-bit operand following the opcode
                        PC+=4;
                        break;

                    default:
                        break;
                }
        }

	} else if ((IR & 0xf0) == 0) { // Memory Op

		switch(IR & 0x0F)
		{

			case 0x00:
				// store ACC
				PC += 3;
				break;

			case 0x01:
				// store ACC
				PC += 2;
				break;

			case 0x02:
				// store ACC [MAR]
				PC++;
				break;

			case 0x04:
				//store MAR
				PC += 3;
				break;

			case 0x05:
				// store MAR
				PC += 3;
				break;

			case 0x06:
				// store MAR
				PC++;
				break;

			case 0x08: // 0000 1000
				// load ACC
				PC += 3;
				break;

			case 0x09: // 0000 1001
				// load ACC
				PC += 3;
				break;

			case 0x0A: // 0000 1010
				// load ACC [MAR]
				PC++;
				break;

			case 0x0C: // 0000 1100
				// load MAR
				PC += 3;
				break;

			case 0x0D: // 0000 1101
				// load MAR
				PC += 3;
				break;

			case 0x0E: // 0000 1110
				// load MAR
				PC++;
				break;

		}

    } else if ((IR & 0xF8) == 0x10) { /* Branch/Jump */
        // if first 5 bits are 00010, branch/jump operation

        /* SARAH PC INCREMENT CODE HERE */

    } else { /* Special or illegal Opcode */

    }
}

void executeInstruction()
{

    // vars
    int dest; //destination
    int source; //source

	// checking opcode
	if((IR & 0x80) == 0x80) // Mathematical Op
	{
        // check destination
        switch(IR & 0x0c){
            case 0x00:
                // indirect (MAR used as pointer)
                dest = memory[MAR];
                break;

            case 0x4:
                // Accumulator ACC
                dest = ACC;
                break;

            case 0x8:
                // Address register MAR
                dest = MAR
                break;

            case 0xc:
                // memory
                if ((IR & 0x02) == 0)
                    dest = memory[((memory[PC-2] << 8) + memory[PC-1])];
                else
                    dest = memory[((memory[PC-4] << 8) + memory[PC-3])];
                break;

            default:
                break;
        }

        // check source
        switch(IR & 0x03){

            case 0x00:
                // indirect (MAR used as pointer)
                source = memory[MAR];
                break;

            case 0x01:
                // Accumulator ACC
                source = ACC;
                break;

            case 0x02:
                // Constant
                S = memory[PC-1];
                if ((IR & 0x0c) == 0x8)
                    S += memory[PC-2] << 8;
                break;

            case 0x03:
                // Memory
                if ((IR & 0x0c) == 0x8){
                    source <<= 8;
                    source += memory[(memory[PC-2] << 8) + memory[PC-1]+1];
                }
                break;
        }

        switch(IR & 0x80){

            case 0x00: //and
                dest &= source;
                break;

            case 0x10: //or
                dest |= source;
                break;

            case 0x20: // xor
                dest ^= source;
                break;

            case 0x30: // add
                dest += source;
                break;

            case 0x40: // sub
                dest -= source;
                break;

            case 0x50: // inc
                dest++;
                break;

            case 0x60: // dec
                dest--;
                break;

            case 0x70: // not
                dest = !dest;
                break;
        }

        switch (IR & 0x0c){ // Checks the store destination

            case 0x0: // Indirect (MAR used as pointer)
                memory[MAR] = dest & 0xff;
                break;

            case 0x4: // Accumulator ACC
                ACC = dest & 0xff;
                break;

            case 0x8: // Address register MAR
                MAR = dest & 0xffff;
                break;

            case 0xc: // Memory
                memory[((memory[PC-2] << 8) + memory[PC-1])] = (dest >> 8) & 0xff;
                memory[((memory[PC-2] << 8) + memory[PC-1]) + 1] = dest & 0xff;
                break;
        }


	} else if ((IR & 0xF0) == 0) { // Memory Op

		// executing the instruction
		switch(IR & 0x0F)
		{

			case 0x00:
				// store ACC
				memory[ (memory[PC-2]<<8) + memory[PC-1] ] = ACC;
				break;

			case 0x01:
				// store ACC
				memory[PC-1] = ACC;
				break;

			case 0x02:
				// store ACC [MAR]
				memory[MAR] = ACC;
				break;

			case 0x04:
				//store MAR
				memory[ (memory[PC-2] << 8) + memory[PC-1] ] = MAR >> 8;
				memory[ (memory[PC-2] << 8) + memory[PC-1] + 1 ] = MAR - ( (MAR >> 8) << 8);
				break;

			case 0x05:
				// store MAR
				memory[ (memory[PC-2] << 8) + memory[PC-1] ] = MAR;
				break;

			case 0x06:
				// store MAR [MAR]
				memory[MAR] = MAR >> 8;
				memory[MAR + 1] = MAR - ((MAR >> 8) <<8);
				break;

			case 0x08:
				// load ACC
				ACC = memory[ (memory[PC+1]<<8) + memory[PC+2] ];
				break;

			case 0x09:
				// load ACC
				ACC = memory[PC-1];
				break;

			case 0x0A:
				// load ACC [MAR]
				ACC = memory[MAR];
				break;

			case 0x0C:
				// load MAR
				MAR = ((memory[memory[PC-2]]) << 8) + memory[memory[PC-1]];
				break;

			case 0x0D:
				// load MAR
				MAR = (memory[PC-2]<<8) + memory[PC-1];
				break;

			case 0x0E:
				// load MAR [MAR]
				MAR = memory[(memory[PC-2]<<8) + memory[PC-1]];
				break;

		}

	} else if ((IR & 0xF8) == 0x10) { /* Branch/Jump */
			// if first 5 bits are 00010, branch/jump operation

			/* SARAH INSTRUCTION CODE HERE */

    } else { /* Special Opcode */
			// else its a special opcode

    }

}
